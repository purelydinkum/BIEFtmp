﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Get_Auth
{
    class Program
    {
        static void Main(string[] args)
        {

            string sys = ConfigurationManager.AppSettings["Csv_sys"];
            string type = ConfigurationManager.AppSettings["Csv_type"];

            ////////jenkins
            if (ConfigurationManager.AppSettings["Get_Jenkins"] == "true")
            {

                string Jenkins_GetAD = ConfigurationManager.AppSettings["Jenkins_GetAD"];
                bool AD_Status = false;
                if (Jenkins_GetAD == "true")
                {
                    AD_Status = CheckAd();
                }

                string Jenkins_Config_Tmp_Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Jenkins_Config.xml");
                File.Copy(ConfigurationManager.AppSettings["Jenkins_ConfigPath"], Jenkins_Config_Tmp_Path, true);
                var allLines = File.ReadAllLines(Jenkins_Config_Tmp_Path);
                allLines[0] = "<?xml version='1.0' encoding='UTF-8'?>";
                File.WriteAllLines(Jenkins_Config_Tmp_Path, allLines);

                XElement xElement = XElement.Load(Jenkins_Config_Tmp_Path);
                var rolemaps = xElement.Element("authorizationStrategy").Elements("roleMap");

                List<string> Jenkins_csv = new List<string>();
                foreach (var rolemap in rolemaps)
                {
                    if (rolemap.Attribute("type")?.Value.Trim() == "globalRoles")
                    {
                        foreach (var role in rolemap.Elements("role"))
                        {
                            string userrole = "";
                            if (role.Element("permissions")?.Elements("permission")?.FirstOrDefault(x => x.Value == "hudson.model.Hudson.Administer") != null)
                            {
                                userrole = "UserACAdmin";
                            }
                            else
                            {
                                userrole = "UserAC";
                            }

                            foreach (var item in role.Element("assignedSIDs").Elements())
                            {
                                bool isUser = int.TryParse(item.Value.TrimStart('t'), out int _);
                                string SisUser = "";
                                if (isUser)
                                {
                                    SisUser = "Y";
                                }
                                else
                                {
                                    SisUser = "N";
                                }
                                string displayName = item.Value;
                                if (AD_Status)
                                {
                                    string ad_displayName = GetAd(item.Value);
                                    if (!string.IsNullOrEmpty(ad_displayName))
                                    {
                                        displayName = ad_displayName;
                                    }
                                }
                                string line = string.Format("{0},{1},{2},{3},Y,{4},N,{5}",
                                    sys,
                                    type,
                                    SisUser,
                                    item.Value,
                                    userrole,
                                    displayName);
                                Jenkins_csv.Add(line);
                            }
                        }
                    }
                }

                string Jenkins_Csv_Dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Jenkins_Csv");
                if (!Directory.Exists(Jenkins_Csv_Dir))
                {
                    Directory.CreateDirectory(Jenkins_Csv_Dir);
                }

                File.WriteAllLines(Path.Combine(Jenkins_Csv_Dir, string.Format("ACC-Jenkins-{0}.csv", DateTime.Now.ToString("yyyyMMdd"))), Jenkins_csv);
                File.WriteAllLines(Path.Combine(Jenkins_Csv_Dir, string.Format("ACC-Jenkins-{0}-ctl.csv", DateTime.Now.ToString("yyyyMMdd"))), new List<string> { string.Format("{0},{1}", sys, Jenkins_csv.Count) });
            }
            /////gitblit
            if (ConfigurationManager.AppSettings["Get_Gitblit"] == "true")
            {
                string Gitblit_Config_Tmp_Path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "users.conf");
                File.Copy(ConfigurationManager.AppSettings["Gitblit_ConfigPath"], Gitblit_Config_Tmp_Path, true);
                string[] allLines = File.ReadAllLines(Gitblit_Config_Tmp_Path);

                List<Gitblit_User> Gitblit_Users = new List<Gitblit_User>();
                List<Gitblit_Team> Gitblit_Teams = new List<Gitblit_Team>();
                Gitblit_User user = new Gitblit_User();
                Gitblit_Team team = new Gitblit_Team();
                List<string> user_role = new List<string>();
                List<string> user_repository = new List<string>();
                List<string> team_users = new List<string>();
                List<string> team_repository = new List<string>();
                Gitblit_Type class_type = Gitblit_Type.none;
                foreach (var Line in allLines)
                {
                    if (Line.IndexOf("[") == 0)
                    {
                        if (class_type == Gitblit_Type.inUser)
                        {
                            user.role = user_role;
                            user.repository = user_repository;
                            Gitblit_Users.Add(user);
                        }
                        else if(class_type == Gitblit_Type.inTeam)
                        {
                            team.users = team_users;
                            team.repository = team_repository;
                            Gitblit_Teams.Add(team);
                        }
                        if (Line.IndexOf("[user") == 0)
                        {
                            //in user
                            user = new Gitblit_User();
                            user_role = new List<string>();
                            user_repository = new List<string>();
                            user.Name = Line.Split('"')[1];
                            class_type = Gitblit_Type.inUser;
                            continue;
                        }
                        else if (Line.IndexOf("[team") == 0)
                        {
                            //in team
                            team = new Gitblit_Team();
                            team_users = new List<string>();
                            team_repository = new List<string>();
                            team.Name = Line.Split('"')[1];
                            class_type = Gitblit_Type.inTeam;
                            continue;
                        }
                    }
                    
                    if (class_type == Gitblit_Type.inUser)
                    {
                        if(Regex.Split(Line, "password = ", RegexOptions.IgnoreCase).Count() == 2)
                        {
                            user.password = Regex.Split(Line, "password = ", RegexOptions.IgnoreCase)[1].Trim();
                        }
                        else if (Line.Contains(@"role = ""#admin"""))
                        {
                            user.isadmin = true;
                        }
                        else if (Regex.Split(Line, "cookie = ", RegexOptions.IgnoreCase).Count() == 2)
                        {
                            user.cookie = Regex.Split(Line, "cookie = ", RegexOptions.IgnoreCase)[1].Trim();
                        }
                        else if (Regex.Split(Line, "displayName = ", RegexOptions.IgnoreCase).Count() == 2)
                        {
                            user.displayName = Regex.Split(Line, "displayName = ", RegexOptions.IgnoreCase)[1].Trim();
                        }
                        else if (Regex.Split(Line, "accountType = ", RegexOptions.IgnoreCase).Count() == 2)
                        {
                            user.accountType = Regex.Split(Line, "accountType = ", RegexOptions.IgnoreCase)[1].Trim();
                        }
                        else if (Line.Contains(@"disabled = true"))
                        {
                            user.disabled = true;
                        }
                        else if (Regex.Split(Line, "emailMeOnMyTicketChanges = ", RegexOptions.IgnoreCase).Count() == 2)
                        {
                            user.emailMeOnMyTicketChanges = Regex.Split(Line, "emailMeOnMyTicketChanges = ", RegexOptions.IgnoreCase)[1].Trim();
                        }
                        else if (Regex.Split(Line, "role = ", RegexOptions.IgnoreCase).Count() == 2)
                        {
                            user_role.Add(Regex.Split(Line, "role = ", RegexOptions.IgnoreCase)[1].Trim());
                        }
                        else if (Regex.Split(Line, "repository = ", RegexOptions.IgnoreCase).Count() == 2)
                        {
                            user_repository.Add(Regex.Split(Line, "repository = ", RegexOptions.IgnoreCase)[1].Trim());
                        }
                    }
                    else if (class_type == Gitblit_Type.inTeam)
                    {
                        if (Line.Contains(@"role = ""#admin"""))
                        {
                            team.isadmin = true;
                        }
                        else if (Regex.Split(Line, "user = ", RegexOptions.IgnoreCase).Count() == 2)
                        {
                            team_users.Add(Regex.Split(Line, "user = ", RegexOptions.IgnoreCase)[1].Trim());
                        }
                        else if (Regex.Split(Line, "repository = ", RegexOptions.IgnoreCase).Count() == 2)
                        {
                            team_repository.Add(Regex.Split(Line, "repository = ", RegexOptions.IgnoreCase)[1].Trim());
                        }
                    }
                }

                team.users = team_users;
                team.repository = team_repository;
                Gitblit_Teams.Add(team);

                List<string> Gitblit_csv = new List<string>();
                foreach (var User in Gitblit_Users)
                {
                    string userrole = "";
                    if (User.isadmin)
                    {
                        userrole = "UserACAdmin";
                    }
                    else if (Gitblit_Teams.FirstOrDefault(x => x.isadmin == true && x.users.Contains(User.Name)) != null)
                    {
                        userrole = "UserACAdmin";
                    }
                    else
                    {
                        userrole = "UserAC";
                        //沒有考慮到人直接加入repo或設定在專案owner
                        //if (ConfigurationManager.AppSettings["Gitblit_OnlyUsedRepo"] == "true")
                        //{
                        //    if(Gitblit_Teams.FirstOrDefault(x => x.repository.Count != 0 && x.users.Contains(User.Name)) == null)
                        //    {
                        //        continue;
                        //    }
                        //}
                    }

                    bool isUser = int.TryParse(User.Name.TrimStart('t'), out int _);
                    string SisUser = "";
                    if (isUser)
                    {
                        SisUser = "Y";
                    }
                    else
                    {
                        SisUser = "N";
                    }
                    string Sdisabled = "";
                    if (User.disabled)
                    {
                        Sdisabled = "F";
                    }
                    else
                    {
                        Sdisabled = "N";
                    }
                    string displayName = string.IsNullOrEmpty(User.displayName) ? User.Name : User.displayName;

                    string line = string.Format("{0},{1},{2},{3},Y,{4},{5},{6}",
                        sys,
                        type,
                        SisUser,
                        User.Name,
                        userrole,
                        Sdisabled,
                        displayName);
                    Gitblit_csv.Add(line);
                }

                string Gitblit_Csv_Dir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Gitblit_Csv");
                if (!Directory.Exists(Gitblit_Csv_Dir))
                {
                    Directory.CreateDirectory(Gitblit_Csv_Dir);
                }

                File.WriteAllLines(Path.Combine(Gitblit_Csv_Dir, string.Format("ACC-Gitblit-{0}.csv", DateTime.Now.ToString("yyyyMMdd"))), Gitblit_csv);
                File.WriteAllLines(Path.Combine(Gitblit_Csv_Dir, string.Format("ACC-Gitblit-{0}-ctl.csv", DateTime.Now.ToString("yyyyMMdd"))), new List<string> { string.Format("{0},{1}", sys, Gitblit_csv.Count) });
            }
        }

        private static bool CheckAd()
        {
            string Domain = ConfigurationManager.AppSettings["Jenkins_AD_Domain"];
            string User = ConfigurationManager.AppSettings["Jenkins_AD_User"];
            PHelper pHelper = new PHelper();
            string Token = pHelper.Decrypt(ConfigurationManager.AppSettings["Jenkins_AD_Token"]);

            using (DirectoryEntry entry = new DirectoryEntry($"LDAP://{Domain}", User, Token))
            {
                try
                {
                    Object obj = entry.NativeObject;
                    return true;
                }catch (Exception ex)
                {
                    return false;
                }
            }
        }
        private static string GetAd(string id)
        {
            string Domain = ConfigurationManager.AppSettings["Jenkins_AD_Domain"];
            string User = ConfigurationManager.AppSettings["Jenkins_AD_User"];
            PHelper pHelper = new PHelper();
            string Token = pHelper.Decrypt(ConfigurationManager.AppSettings["Jenkins_AD_Token"]);
            string Filter_Name = ConfigurationManager.AppSettings["Jenkins_AD_Filter_Name"];
            string Search_Name = ConfigurationManager.AppSettings["Jenkins_AD_Search_Name"];

            using (DirectoryEntry entry = new DirectoryEntry($"LDAP://{Domain}", User, Token))
            {
                DirectorySearcher ads = new DirectorySearcher(entry);
                ads.Filter = Filter_Name + "=" + id;
                SearchResult searchResult = ads.FindOne();
                if (searchResult != null)
                {
                    var r = searchResult.Properties[Search_Name];
                    if (r != null && r.Count > 0)
                    {
                        return searchResult.Properties[Search_Name][0].ToString();
                    }
                }
            }
            return null;

        }
        public enum Gitblit_Type
        {
            none = 0,
            inUser = 1,
            inTeam = 2
        }
        public class Gitblit_User
        {
            public string Name { get; set; }
            public bool isadmin { get; set; }
            public string password { get; set; }
            public string cookie { get; set; }
            public string displayName { get; set; }
            public string accountType { get; set; }
            public bool disabled { get; set; }
            public string emailMeOnMyTicketChanges { get; set; }
            public List<string> role { get; set; }
            public List<string> repository { get; set; }
        }
        public class Gitblit_Team
        {
            public string Name { get; set; }
            public bool isadmin { get; set; }
            public List<string> repository { get; set; }
            public List<string> users { get; set; }
        }
    }
}
