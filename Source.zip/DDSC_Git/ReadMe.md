1.使用Diff 必須安裝node.js
2.使用Diff 路徑不能有中文
3.2022/04/28 調整git差異比對報表不單純使用LibGit2Sharp，
使用原生git指令。需在git 設定git config --global core.quotepath false，
會使用LibGit2Sharp 傳出之檔案名稱迴圈使用git diff -- 單檔執行。