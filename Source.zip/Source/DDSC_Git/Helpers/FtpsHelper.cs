﻿using FluentFTP;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace DDSC_Git.Helpers
{
    class FtpsHelper
    {
        private readonly FtpClient ftpClient;

        public bool Connected { get { return ftpClient.IsConnected; } }

        #region 構造
        public FtpsHelper(string host,int port, string user,string P)
        {
            ServicePointManager.ServerCertificateValidationCallback +=
            (sender, cert, chain, sslPolicyErrors) => true;
            ftpClient = new FtpClient(host,port, user, P);
            ftpClient.EncryptionMode = FtpEncryptionMode.None;
            ftpClient.SslProtocols = SslProtocols.Tls;
            ftpClient.ValidateCertificate += new FtpSslValidation(OnValidateCertificate);

            void OnValidateCertificate(FtpClient control, FtpSslValidationEventArgs e)
            {
                var cert2 = new X509Certificate2(e.Certificate);
                e.Accept = cert2.Verify();
            }
        }
        #endregion

        #region 連線FTPS
        public void Connect()
        {
            try
            {
                if (!Connected)
                {
                    ftpClient.Connect();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("連線FTPS失敗，原因：{0}", ex.Message));
            }
        }
        #endregion

        #region 斷開FTPS
        public void Disconnect()
        {
            try
            {
                if (ftpClient != null && Connected)
                {
                    ftpClient.Disconnect();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("斷開FTPS失敗，原因：{0}", ex.Message));
            }
        }
        #endregion

        #region FTPS上傳檔案
        /// <summary>
        /// FTPS上傳檔案
        /// </summary>
        /// <param name="localPath">本地路徑</param>
        /// <param name="remotePath">遠端路徑 ex:Return/Windows/20180101/hostname/a.txt</param>
        /// <param name="Auto">自動連線及斷線</param>
        /// <param name="AutoCreateDirectory">自動遞迴建立資料夾</param>
        public bool Put(string localPath, string remotePath, bool Auto = false, bool AutoCreateDirectory = true)
        {
            FtpStatus S;
            if (Auto) Connect();
            if (AutoCreateDirectory)
            {
               S = ftpClient.UploadFile(localPath, remotePath, createRemoteDir: true);
            }
            else
            {
               S = ftpClient.UploadFile(localPath, remotePath);
            }
            if (Auto) Disconnect();

            if( S == FtpStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region FTPS建立資料夾
        /// <summary>
        /// FTPS上傳檔案
        /// </summary>
        /// <param name="remoteDirectory">遠端路徑 ex:Return/Windows/20180101/hostname</param>
        /// <param name="Auto">自動連線及斷線</param>
        public bool CreateDirectory(string remoteDirectory, bool Auto = false)
        {
            bool R;
            if (Auto) Connect();
            R = ftpClient.CreateDirectory(remoteDirectory, true);
            if (Auto) Disconnect();

            return R;
        }
        #endregion

        #region FTPS獲取檔案
        /// <summary>
        /// FTPS獲取檔案
        /// </summary>
        /// <param name="remotePath">遠端路徑</param>
        /// <param name="localPath">本地路徑</param>
        /// <param name="Auto">自動連線及斷線</param>
        public bool Get(string remotePath, string localPath, bool Auto = false)
        {
            FtpStatus S;
            if (Auto) Connect();
            S = ftpClient.DownloadFile(localPath, remotePath);
            if (Auto) Disconnect();

            if (S == FtpStatus.Success)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion


        #region FTPS下載資料夾
        /// <summary>
        /// FTPS下載資料夾
        /// </summary>
        /// <param name="remotePath">遠端路徑</param>
        /// <param name="localPath">本地路徑</param>
        /// <param name="Auto">自動連線及斷線</param>
        public void DownloadDirectory(string remotePath, string localPath, bool Auto = false)
        {
            if (Auto) Connect();
            ftpClient.DownloadDirectory(localPath, remotePath);
            if (Auto) Disconnect();
        }
        #endregion
        #region 刪除FTPS檔案
        /// <summary>
        /// 刪除FTPS檔案
        /// </summary>
        /// <param name="remoteFile">遠端路徑</param>
        /// <param name="Auto">自動連線及斷線</param>
        public void Delete(string remoteFile, bool Auto = false)
        {
            if (Auto) Connect();
            ftpClient.DeleteFile(remoteFile);
            if (Auto) Disconnect();
        }
        #endregion

        #region 刪除FTPS資料夾
        /// <summary>
        /// 刪除FTPS資料夾
        /// </summary>
        /// <param name="remoteDirectory">遠端資料夾路徑</param>
        /// <param name="keeproot">保留根資料夾</param>
        public void DeleteDirectory(string remoteDirectory, bool keeproot = true, bool Auto = false)
        {
            if (Auto) Connect();
            if (keeproot)
            {
                FtpListItem[] List = ftpClient.GetListing(remoteDirectory);
                foreach (var item in List)
                {
                    if(item.Type == FtpFileSystemObjectType.Directory)
                    {
                        DeleteDirectory(item.FullName, keeproot: false);
                    }
                    else
                    {
                        Delete(item.FullName);
                    }
                }
            }
            else
            {
                ftpClient.DeleteDirectory(remoteDirectory);
            }
            if (Auto) Disconnect();
        }
        #endregion

        #region 獲取FTPS檔案列表
        /// <summary>
        /// 獲取FTPS檔案列表
        /// </summary>
        /// <param name="remotePath">遠端目錄</param>
        /// <param name="Auto">自動連線及斷線</param>
        /// <returns></returns>
        public string[] GetFileList(string remotePath, bool Auto = false)
        {
            string[] R;
            if (Auto) Connect();
            R = ftpClient.GetNameListing(remotePath);
            if (Auto) Disconnect();

            return R;
        }
        #endregion

        #region 移動FTPS檔案
        /// <summary>
        /// 移動FTPS檔案
        /// </summary>
        /// <param name="oldRemotePath">舊遠端路徑</param>
        /// <param name="newRemotePath">新遠端路徑</param>
        /// <param name="Auto">自動連線及斷線</param>
        public bool Move(string oldRemotePath, string newRemotePath, bool Auto = false)
        {
            bool R;
            if (Auto) Connect();
            R = ftpClient.MoveFile(oldRemotePath, newRemotePath);
            if (Auto) Disconnect();

            return R;
        }
        #endregion

        #region 移動FTPS資料夾
        /// <summary>
        /// 移動FTPS檔案
        /// </summary>
        /// <param name="oldRemotePath">舊遠端路徑</param>
        /// <param name="newRemotePath">新遠端路徑</param>
        /// <param name="Auto">自動連線及斷線</param>
        public bool MoveDirectory(string oldRemotePath, string newRemotePath, bool Auto = false)
        {
            bool R;
            if (Auto) Connect();
            R = ftpClient.MoveDirectory(oldRemotePath, newRemotePath);
            if (Auto) Disconnect();

            return R;
        }
        #endregion


    }
}
