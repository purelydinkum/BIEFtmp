﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using LibGit2Sharp;
using LibGit2Sharp.Handlers;

namespace DDSC_Git.Helpers
{
    class GitHelper
    {
        string _GitPath;
        public GitHelper(string GitPath)
        {
            _GitPath = GitPath;

        }
        
        public ResultDiff GetDiff(string SourceVersion,string TargetVersion, bool norenames = true, bool ignorespace = true)
        {
            ResultDiff R = new ResultDiff();
            R.Status = Status.none;
            string changedContent;
            string comparedContent;
            string comparedContentOrigin;
            List<string> AorMFilesPath;
            if (!Repository.IsValid(_GitPath))
            {
                R.Status = Status.Failed;
                R.Message = "Path is not Git dir!!";
                return R;
            }
            using (Repository repo = new Repository(_GitPath))
            {
                var sourceInfo = getRefsInfo(repo, SourceVersion);
                if (sourceInfo.Status != Status.Success)
                {
                    R.Status = sourceInfo.Status;
                    R.Message = sourceInfo.Message;
                    return R;
                }
                
                var targetInfo = getRefsInfo(repo, TargetVersion);
                if (targetInfo.Status != Status.Success)
                {
                    R.Status = targetInfo.Status;
                    R.Message = targetInfo.Message;
                    return R;
                }

                ChangedResult changedResult = getChangedContent(repo, sourceInfo, targetInfo, "", norenames: norenames, ignorespace: ignorespace);
                changedContent = changedResult.Content;
                //comparedContent = getComparedContent(repo, sourceInfo, targetInfo, "", norenames: norenames, ignorespace: ignorespace);
                //comparedContentOrigin = getComparedContent(repo, sourceInfo, targetInfo, "", Origin:true, norenames: norenames, ignorespace: ignorespace);
                comparedContent = getComparedContent_Cmd(repo, sourceInfo, targetInfo, "", norenames: norenames, ignorespace: ignorespace);
                comparedContentOrigin = getComparedContent_Cmd(repo, sourceInfo, targetInfo, "",Origin:true, norenames: norenames, ignorespace: ignorespace);
                AorMFilesPath = changedResult.AorMFilesPath;
                //getDiffObject(repo, sourceInfo, targetInfo, tempWorkDirectory, DiffFilter);
            }

            R.Status = Status.Success;
            R.ChangedContent = changedContent;
            R.ComparedContent = comparedContent;
            R.ComparedContentOrigin = comparedContentOrigin;
            R.AorMFilesPath = AorMFilesPath;
            return R;
        }

        public ResultTag GetTagVersion(bool SyncRemoteTag ,string Tag_Type)
        {
            ResultTag R = new ResultTag();
            R.Status = Status.none;
            R.Tag_Type = Tag_Type;
            if (!Repository.IsValid(_GitPath))
            {
                R.Status = Status.Failed;
                R.Message = "Path is not Git dir!!";
                return R;
            }

            List<TagsPoints> Tags = new List<TagsPoints>();
            string headSha;
            ILookup<ObjectId, Tag> commitIdToTagLookup ;
            using (Repository repo = new Repository(_GitPath))
            {
                if (SyncRemoteTag)
                {
                    IEnumerable<string> refSpec = new List<string>() { "+refs/tags/*:refs/tags/*" };
                    FetchOptions fetchoptions = new FetchOptions() { Prune = true ,
                        CredentialsProvider = GetCredentialsHandler(), TagFetchMode = TagFetchMode.All };
                    repo.Network.Fetch("origin", refSpec, fetchoptions) ;
                }
                headSha = repo.Head.Tip.Sha;
                var a = repo.Tags;
                commitIdToTagLookup = CreateCommitIdToTagLookup(repo);
            }

            foreach (var Commit in commitIdToTagLookup)
            {
                foreach (var tag in Commit)
                {
                    Tags.Add(new TagsPoints() {SHA = Commit.Key.Sha, TagName = tag.FriendlyName});
                }
            }

            #region 取得Tag版本並排序，並取得最新Tag版本
            List<TagsPoints> TargetTags = Tags.Where(x => Regex.IsMatch(x.TagName, @"^"+ Tag_Type + @"_\d{3}SC\d{4}$")).OrderByDescending(x => x.TagName).ToList();
            R.TagsList = TargetTags;
            R.NowTag = TargetTags.FirstOrDefault();
            #endregion
            #region 算出上一版Tag版本
            if(TargetTags.Count >= 2)
            {
                R.PreviousTag = TargetTags[1];
            }
            #endregion
            #region 算出下一版Tag版本
            string Year = (DateTime.Now.Year - 1911).ToString();
            TagsPoints YearFirstTag = TargetTags.Where(x => Regex.IsMatch(x.TagName, @"^" + Tag_Type + @"_" + Year + @"SC\d{4}$")).FirstOrDefault();
            TagsPoints NextTag = new TagsPoints();
            if (YearFirstTag == null)
            {
                string Version = "0001";
                NextTag.TagName = string.Format("{0}_{1}SC{2}", Tag_Type, Year, Version);
            }
            else
            {
                int Num = 0;
                if (Tag_Type == ResultTag.Tag_Type_RTM)
                {
                    Num = 9;
                }
                else
                {
                    Num = 10;
                }
                string Version = (int.Parse(YearFirstTag.TagName.Substring(Num, 4)) + 1).ToString("0000");
                NextTag.TagName = string.Format("{0}_{1}SC{2}", Tag_Type, Year, Version);
            }
            R.NextTag = NextTag;
            #endregion
            #region 取得當下head已打上Tag版本
            TagsPoints HEADTag = TargetTags.Where(x => x.SHA == headSha).FirstOrDefault();
            R.HeadTag = HEADTag;
            #endregion

            R.Status = Status.Success;
            return R;
        }

        public Result TagPush(string TagName,string Type,string Message = "")
        {
            Result R = new Result();
            R.Status = Status.none;
            if (!Repository.IsValid(_GitPath))
            {
                R.Status = Status.Failed;
                R.Message = "Path is not Git dir!!";
                return R;
            }

            using (Repository repo = new Repository(_GitPath))
            {
                PushOptions options = new PushOptions() { CredentialsProvider = GetCredentialsHandler() };
                options.CertificateCheck = (_a, _b, _c) => { return true; };

                Remote remote = repo.Network.Remotes["origin"];
                string rfspec = "refs/tags/" + TagName;

                string headSha = repo.Head.Tip.Sha;
                if(Type.ToLower() == "add")
                {
                    if (string.IsNullOrEmpty(Message))
                    {
                        _ = repo.Tags.Add(TagName, headSha);
                    }
                    else
                    {
                        _ = repo.Tags.Add(TagName,
                        headSha, new Signature(new Identity(ConfigurationManager.AppSettings["Push_Name"],
                        ConfigurationManager.AppSettings["Push_Email"]),
                        new DateTimeOffset(DateTime.Now)), Message);
                    }

                    repo.Network.Push(remote, rfspec, rfspec, options);
                }
                else if (Type.ToLower() == "update")
                {
                    if (string.IsNullOrEmpty(Message))
                    {
                        _ = repo.Tags.Add(TagName,headSha, true);
                    }
                    else
                    {
                        var _ = repo.Tags.Add(TagName,
                        headSha, new Signature(new Identity(ConfigurationManager.AppSettings["Push_Name"],
                        ConfigurationManager.AppSettings["Push_Email"]),
                        new DateTimeOffset(DateTime.Now)), Message,true);
                    }
                    repo.Network.Push(remote, ":" + rfspec, options);
                    repo.Network.Push(remote, rfspec , rfspec, options);
                }
                else if (Type.ToLower() == "remove")
                {
                    repo.Network.Push(remote, ":" + rfspec, options);
                }
                else
                {
                    R.Status = Status.Failed;
                    R.Message = "Type is not in (Add,Update,Remove) !!";
                    return R;
                }
            }

            R.Status = Status.Success;
            return R;
        }

        private CredentialsHandler GetCredentialsHandler()
        {
            PHelper P = new PHelper();

            var creds = new UsernamePasswordCredentials()
            {
                Username = P.Decrypt(ConfigurationManager.AppSettings["Push_U"]),
                Password = P.Decrypt(ConfigurationManager.AppSettings["Push_P"])
            };
            CredentialsHandler credHandler = (_url, _user, _cred) => creds;

            return credHandler;
        }
        public class Result
        {
            public string Message { get; set; }
            public Status Status  { get; set; }

        }

        public class ResultDiff : Result
        {
            public string ChangedContent { get; set; }
            public string ComparedContent { get; set; }
            public string ComparedContentOrigin { get; set; }
            public List<string> AorMFilesPath { get; set; }

        }

        public class ResultTag : Result
        {
            public string Tag_Type { get; set; }

            public List<TagsPoints> TagsList { get; set; }
            public TagsPoints NextTag { get; set; }

            public TagsPoints NowTag { get; set; }

            public TagsPoints PreviousTag { get; set; }

            public TagsPoints HeadTag { get; set; }

            public static readonly string Tag_Type_RTM = "RTM";
            public static readonly string Tag_Type_SCAN = "SCAN";
        }


        public enum Status
        {
        none,
        Success,
        Failed
        }

        //
        // 摘要:
        //     The kind of changes that a Diff can report.
        public enum ChangeKindChinese
        {
            //
            // 摘要:
            //     No changes detected.
            未修改 = 0,
            //
            // 摘要:
            //     The file was added.
            新增 = 1,
            //
            // 摘要:
            //     The file was deleted.
            刪除 = 2,
            //
            // 摘要:
            //     The file content was modified.
            修改 = 3,
            //
            // 摘要:
            //     The file was renamed.
            重新命名 = 4,
            //
            // 摘要:
            //     The file was copied.
            複製 = 5,
            //
            // 摘要:
            //     The file is ignored in the workdir.
            忽略 = 6,
            //
            // 摘要:
            //     The file is untracked in the workdir.
            未追蹤 = 7,
            //
            // 摘要:
            //     The type (i.e. regular file, symlink, submodule, ...) of the file was changed.
            類型變更 = 8,
            //
            // 摘要:
            //     Entry is unreadable.
            不可讀 = 9,
            //
            // 摘要:
            //     Entry is currently in conflict.
            矛盾 = 10
        }

        /// <summary>
        /// 用以描述版本資訊。
        /// </summary>
        public class RefsInfo : Result
        {

            /// <summary>
            /// 取得版本類型。
            /// </summary>
            /// <value>用以取得版本類型。</value>
            public string Type { get; set; }

            /// <summary>
            /// 取得版本名稱。
            /// </summary>
            /// <value>用以取得版本名稱。</value>
            public string Name { get; set; }

            /// <summary>
            /// 取得版本對應得 SHA1 碼。
            /// </summary>
            /// <value>用以取得版本對應得 SHA1 碼。</value>
            public string SHA { get; set; }
            public static readonly string Branch = "Branch";
            public static readonly string Tag = "Tag";
            public static readonly string CommitId = "SHA";
            public static readonly string HEADRef = "HEADRef";
            public static readonly string TagRef = "TagRef";
        }

        public class ChangedResult
        {
            public string Content { get; set; }
            public List<string> AorMFilesPath { get; set; }
        }
        private string getHeaderContent(RefsInfo refsSource, RefsInfo refsTarget)
        {
            string Content = string.Empty;
            Content += "===================================================================" + Environment.NewLine;
            Content += "產生時間 : " + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + Environment.NewLine;
            Content += "來源     : " + refsSource.Name + Environment.NewLine;
            Content += "來源類型 : " + refsSource.Type + Environment.NewLine;
            Content += "來源SHA  : " + refsSource.SHA + Environment.NewLine;
            Content += "目標     : " + refsTarget.Name + Environment.NewLine;
            Content += "目標類型 : " + refsTarget.Type + Environment.NewLine;
            Content += "目標SHA  : " + refsTarget.SHA + Environment.NewLine;
            Content += "===================================================================" + Environment.NewLine;

            return Content;
        }
        private ChangedResult getChangedContent(Repository targetRepository, RefsInfo refsSource, RefsInfo refsTarget, string DiffFilter, bool norenames = true, bool ignorespace = true)
        {
            ChangedResult R = new ChangedResult();
            string Content = string.Empty;
            Content += getHeaderContent(refsSource, refsTarget);
            SimilarityOptions _SimilarityOptions = new SimilarityOptions();
            if (norenames)
            {
                _SimilarityOptions.RenameDetectionMode = RenameDetectionMode.None;
            }
            if (ignorespace)
            {
                _SimilarityOptions.WhitespaceMode = WhitespaceMode.IgnoreLeadingWhitespace;
            }
            var changelist =
                targetRepository.Diff.Compare<TreeChanges>(
                    targetRepository.Lookup<Commit>(refsTarget.SHA).Tree,
                    targetRepository.Lookup<Commit>(refsSource.SHA).Tree, 
                    new CompareOptions { Similarity = _SimilarityOptions
                    }).ToList();

            List<string> changedFilesPath = new List<string>();
            foreach (var item in Enum.GetValues(typeof(ChangeKind)).Cast<ChangeKind>())
            {
                var NameResult = changelist.Where(d => d.Status == item && inDiffFilter(d.Path, DiffFilter));
                if (NameResult.Count() != 0)
                {
                    ChangeKindChinese changeKindChinese = (ChangeKindChinese)(int)item;
                    Content += "[" + changeKindChinese + ":" + NameResult.Count() + "]" + Environment.NewLine;
                    foreach (TreeEntryChanges c in NameResult)
                    {
                        Content += c.Path + Environment.NewLine;

                        if (changeKindChinese == ChangeKindChinese.新增 || changeKindChinese == ChangeKindChinese.修改)
                        {
                            changedFilesPath.Add(c.Path);
                        }
                    }
                }
            }

            R.Content = Content;
            R.AorMFilesPath = changedFilesPath;
            return R;
        }
        private string getComparedContent(Repository targetRepository, RefsInfo refsSource, RefsInfo refsTarget, string DiffFilter, bool Origin = false, bool norenames = true, bool ignorespace = true)
        {
            string Content = string.Empty;
            if (!Origin)
            {
                Content += getHeaderContent(refsSource, refsTarget);
            }
            SimilarityOptions _SimilarityOptions = new SimilarityOptions();
            if (norenames)
            {
                _SimilarityOptions.RenameDetectionMode = RenameDetectionMode.None;
            }
            if (ignorespace)
            {
                _SimilarityOptions.WhitespaceMode = WhitespaceMode.IgnoreLeadingWhitespace;
            }
            var repoDifferences =
                targetRepository.Diff.Compare<Patch>(
                    targetRepository.Lookup<Commit>(refsTarget.SHA).Tree,
                    targetRepository.Lookup<Commit>(refsSource.SHA).Tree,
                    new CompareOptions
                    {
                        Similarity = _SimilarityOptions
                    }).ToList();

            foreach (var item in repoDifferences)
            {
                if (inDiffFilter(item.Path, DiffFilter))
                {
                    if (!Origin)
                    {
                        Content += "===================================================================" + Environment.NewLine;
                        Content += item.Path + "檔案的差異" + Environment.NewLine;
                        Content += "===================================================================" + Environment.NewLine;
                    }
                    string diffContent = item.Patch;
                    //中文檔案名稱問題
                    if (item.Patch.Length >=16 && item.Patch.Substring(0,14) == "diff --git \"a/")
                    {
                        //有中文檔案名問題
                        int FileindexStart = 14;
                        int FileindexEnd = item.Patch.IndexOf('"', FileindexStart);
                        if(FileindexEnd > FileindexStart)
                        {
                            string FileNameOrigin = item.Patch.Substring(FileindexStart, FileindexEnd - FileindexStart);
                            diffContent = diffContent.Replace(FileNameOrigin, item.Path);
                        }
                    }
                    Content += diffContent + Environment.NewLine;
                }
            }
            return Content;
        }

        private string getComparedContent_Cmd(Repository targetRepository, RefsInfo refsSource, RefsInfo refsTarget, string DiffFilter, bool Origin = false, bool norenames = true, bool ignorespace = true)
        {
            string Content = string.Empty;
            if (!Origin)
            {
                Content += getHeaderContent(refsSource, refsTarget);
            }
            SimilarityOptions _SimilarityOptions = new SimilarityOptions();
            if (norenames)
            {
                _SimilarityOptions.RenameDetectionMode = RenameDetectionMode.None;
            }
            if (ignorespace)
            {
                _SimilarityOptions.WhitespaceMode = WhitespaceMode.IgnoreLeadingWhitespace;
            }
            var changelist =
                targetRepository.Diff.Compare<TreeChanges>(
                    targetRepository.Lookup<Commit>(refsTarget.SHA).Tree,
                    targetRepository.Lookup<Commit>(refsSource.SHA).Tree,
                    new CompareOptions
                    {
                        Similarity = _SimilarityOptions
                    }).ToList();

            foreach (var item in Enum.GetValues(typeof(ChangeKind)).Cast<ChangeKind>())
            {
                var NameResult = changelist.Where(d => d.Status == item && inDiffFilter(d.Path, DiffFilter));
                if (NameResult.Count() != 0)
                {
                    ChangeKindChinese changeKindChinese = (ChangeKindChinese)(int)item;
                    
                    foreach (TreeEntryChanges c in NameResult)
                    {

                        if (!Origin)
                        {
                            Content += "===================================================================" + Environment.NewLine;
                            string File_Type = "[" + changeKindChinese + "]";
                            Content += File_Type + c.Path + "檔案的差異" + Environment.NewLine;
                            Content += "===================================================================" + Environment.NewLine;
                        }
                        //重要:目前使用git.exe，故只支援CMD指令(如雙引號)，未來若需要git bash可再指定git路徑。
                        string git_diff_cmd = "diff";
                        if (norenames)
                        {
                            git_diff_cmd += " --no-renames";
                        }
                        if (ignorespace)
                        {
                            git_diff_cmd += " --ignore-all-space";
                        }
                        ProcessStartInfo Git_Diff_Cmd = new ProcessStartInfo(@"git", String.Format("{0} {1} {2} -- \"{3}\"",
                        git_diff_cmd, refsTarget.SHA, refsSource.SHA, c.Path))
                        { RedirectStandardOutput = true, RedirectStandardError = true, CreateNoWindow = true, UseShellExecute = false,
                            WorkingDirectory = targetRepository.Info.WorkingDirectory
                            ,StandardOutputEncoding = Encoding.UTF8
                            ,StandardErrorEncoding = Encoding.UTF8
                        };
                        string Git_Diff_result;
                        string Git_Diff_error;
                        using (Process p = Process.Start(Git_Diff_Cmd))
                        {

                            Git_Diff_result = p.StandardOutput.ReadToEnd();
                            Git_Diff_error = p.StandardError.ReadToEnd();
                            p.WaitForExit(60000);
                            if (!p.HasExited)
                            {
                                p.Kill();
                            }
                            p.Close();
                        }
                        Content += Git_Diff_result;

                    }
                }
            }
            
            
            return Content;
        }
        private bool inDiffFilter(string DiffPath, string DiffFilter)
        {
            if (string.IsNullOrEmpty(DiffPath) || string.IsNullOrEmpty(DiffFilter))
            {
                return true;
            }
            foreach (var item in DiffFilter.Split(';'))
            {
                //特殊符號: ^表示開頭，若只在開頭才符合，如 ^Database/SQL :Database/SQL/aaa.sql(符合); Source/Database/SQL/bbb.sql(不符合)
                if (item.Length >= 2 && item.Substring(0, 1) == "^")
                {
                    string _DiffFilter = item.Substring(1);
                    if (DiffPath.Length < _DiffFilter.Length)
                    {
                        return false;
                    }

                    if (DiffPath.Substring(0, _DiffFilter.Length).IndexOf(_DiffFilter, StringComparison.CurrentCultureIgnoreCase) > -1)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    if (DiffPath.IndexOf(item, StringComparison.CurrentCultureIgnoreCase) > -1)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }

            return false;
            //return DiffFilter.Split(";").ToList().Any(s => DiffPath.IndexOf(s, StringComparison.CurrentCultureIgnoreCase) > -1);

        }
       

        private class CommitSearch
        {
            String _s;

            public CommitSearch(String s)
            {
                _s = s;
            }

            public bool StartsWith(Commit e)
            {
                return e.Sha.StartsWith(_s, StringComparison.InvariantCultureIgnoreCase);
            }
        }

        private RefsInfo getRefsInfo(Repository targetRepository, string refName, string refRemoteNmae = "")
        {
            RefsInfo R = new RefsInfo();
            R.Status = Status.none;
            if (refName.ToLower().Trim() == "head")
            {
                R.Type = RefsInfo.HEADRef;
                string head = targetRepository.Head.Tip.Sha;
                if (head != null)
                {
                    R.Status = Status.Success;
                    R.Name = refName;
                    R.SHA = head;
                    return R;
                }
                else
                {
                    R.Status = Status.Failed;
                    R.Message = "head not found!";
                    return R;
                }
            }

            if (refName.Length > 4 && refName.ToLower().Trim().Substring(0, 4) == "tag~")
            {
                R.Type = refName;

                string headref = refName.Trim().Substring(4, refName.Length - 4);
                if (!int.TryParse(headref, out int PreviousNum))
                {
                    R.Status = Status.Failed;
                    R.Message = "tag~N must be number!";
                    return R;
                }

                string HEADcommit = targetRepository.Head.Tip.Sha;
                ResultTag resultTag = GetTagVersion(true, ResultTag.Tag_Type_RTM);

                if (resultTag.HeadTag == null)
                {
                    R.Status = Status.Failed;
                    R.Message = "target not the RTM tag!";
                    return R;
                }
                int HeadTagNum = resultTag.TagsList.FindIndex(x => x.TagName == resultTag.HeadTag.TagName);
                int HeadPreviousNum = HeadTagNum + PreviousNum;
                if (resultTag.TagsList.ElementAtOrDefault(HeadPreviousNum) == null)
                {
                    R.Status = Status.Failed;
                    R.Message = refName + " not exist!";
                    return R;
                }
                TagsPoints tagsPoints = resultTag.TagsList[HeadPreviousNum];

                R.Status = Status.Success;
                R.Name = tagsPoints.TagName;
                R.SHA = tagsPoints.SHA;
                return R;
            }

            if (refName.Length > 5 && refName.ToLower().Trim().Substring(0, 5) == "head~")
            {
                R.Type = RefsInfo.HEADRef;
                string headref = refName.Trim().Substring(5, refName.Length - 5);
                if (!int.TryParse(headref, out int HeadRefNum))
                {
                    R.Status = Status.Failed;
                    R.Message = "head~N must be number!";
                    return R;
                }

                string HEADcommit = targetRepository.Head.Tip.Sha;
                List<Commit> Log = targetRepository.Commits.AsEnumerable().ToList();
                var es = new CommitSearch(HEADcommit);
                int HEADindex = Log.FindIndex(es.StartsWith);
                Commit PreviousHEADCommit = Log.ElementAtOrDefault(HEADindex + HeadRefNum);

                if (PreviousHEADCommit != null)
                {
                    R.Status = Status.Success;
                    R.Name = refName;
                    R.SHA = PreviousHEADCommit.Sha;
                    return R;
                }
                else
                {
                    R.Status = Status.Failed;
                    R.Message = refName + " not exist!";
                    return R;
                }

            }

            string branchRefs = refName;
            if (!string.IsNullOrEmpty(refRemoteNmae))
            {
                string[] map = { "origin/", "ref/", "remote/", "remotes/" };
                string _refname = refName;
                foreach (var m in map)
                {
                    _refname = Regex.Replace(_refname, m, "", RegexOptions.IgnoreCase);
                }

                branchRefs = string.Format(@"{0}/{1}", refRemoteNmae, _refname);
            }

            var branch = targetRepository.Branches[branchRefs];
            if (branch != null)
            {
                R.Status = Status.Success;
                R.Type = RefsInfo.Branch;
                R.Name = refName;
                R.SHA = branch.Tip.Sha;
                return R;
            }

            var remotebranch = targetRepository.Branches["remotes/origin/" + branchRefs];
            if (remotebranch != null)
            {
                R.Status = Status.Success;
                R.Type = RefsInfo.Branch;
                R.Name = refName;
                R.SHA = remotebranch.Tip.Sha;
                return R;
            }

            var tag = targetRepository.Tags[refName];
            if (tag != null)
            {
                R.Status = Status.Success;
                R.Type = RefsInfo.Tag;
                R.Name = refName;
                R.SHA = tag.Target.Sha;
                return R;
            }

            if(refName.Length >= 4)
            {
                var commit = targetRepository.Lookup<Commit>(refName);
                if (commit != null)
                {
                    R.Status = Status.Success;
                    R.Type = RefsInfo.CommitId;
                    R.Name = refName;
                    R.SHA = commit.Sha;
                    return R;
                }
            }

            R.Status = Status.Failed;
            R.Message = refName + "not exist!";
            return R;
        }

        private static IEnumerable<Tag> AssignedTags(Commit commit, Dictionary<ObjectId, List<Tag>> tags)
        {
            if (!tags.ContainsKey(commit.Id))
            {
                return Enumerable.Empty<Tag>();
            }

            return tags[commit.Id];
        }

        private static Dictionary<ObjectId, List<Tag>> TagsPerPeeledCommitId(Repository repo)
        {
            var tagsPerPeeledCommitId = new Dictionary<ObjectId, List<Tag>>();

            foreach (Tag tag in repo.Tags)
            {
                GitObject peeledTarget = tag.PeeledTarget;

                if (!(peeledTarget is Commit))
                {
                    // We're not interested by Tags pointing at Blobs or Trees
                    continue;
                }

                ObjectId commitId = peeledTarget.Id;

                if (!tagsPerPeeledCommitId.ContainsKey(commitId))
                {
                    // A Commit may be pointed at by more than one Tag
                    tagsPerPeeledCommitId.Add(commitId, new List<Tag>());
                }

                tagsPerPeeledCommitId[commitId].Add(tag);
            }

            return tagsPerPeeledCommitId;
        }

        private static ILookup<ObjectId, Tag> CreateCommitIdToTagLookup(Repository repo)
        {
            var commitIdToTagLookup =
                repo.Tags
                .Select(tag => new { Commit = tag.PeeledTarget as Commit, Tag = tag })
                .Where(x => x.Commit != null)
                .ToLookup(x => x.Commit.Id, x => x.Tag);

            return commitIdToTagLookup;
        }
        
        public class TagsPoints
        {
            public string SHA { get; set; }
            public string TagName { get; set; }
        }
    }
}
