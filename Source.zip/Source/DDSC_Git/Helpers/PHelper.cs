﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;

namespace DDSC_Git.Helpers
{
    class PHelper
    {
        private static readonly string key = "FEIBKEY_FEIBKEY_FEIBKEY_FEIBKEY_";
        private static readonly string iv = "FEIBIIV_FEIBIIV_";
        private readonly RNGCryptoServiceProvider rngp = new RNGCryptoServiceProvider();
        private readonly byte[] rb = new byte[4];

        /// <summary>
        /// 取得加密密碼
        /// </summary>
        /// <returns></returns>
        public string getP()
        {
            string P = string.Empty;
            while (!CompareP(P))
            {
                string PChar = "12345678;abcdefhjkmnprstuvwxyz;QAZWSXEDCRFVTGBYHNUJMIKOLP";
                int PLength = 12;


                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                //take out char: 190 giloq IO 

                Dictionary<int, char[]> Dic = new Dictionary<int, char[]>();
                for (int i = 0; i < PChar.Split(';').Count(); i++)
                    Dic.Add(i, PChar.Split(';')[i].ToCharArray());

                int length = Next(PLength, PLength);
                for (int i = 0; i < length; i++)
                    sb.Append(Dic[(i % 3)][Next(Dic[(i % 3)].Length - 1)]);

                P = sb.ToString();
            }

            return Encrypt(P);
        }
        /// <summary>
        /// 比對是否符合密碼規則
        /// </summary>
        /// <param name="P"></param>
        /// <returns></returns>
        private bool CompareP(string P)
        {
            string strNumber = "2345678";
            //string strUpperLetter = "ABCDEFGHJKLMNPQRSTUVWXYZ";
            string strLowerLetter = "abcdefhjkmnprstuvwxyz";

            bool Result = false;
            foreach (char c in P)
            {
                if (strNumber.IndexOf(c) > -1)
                {
                    Result = true;
                    break;
                }
            }

            if (Result)
            {

                if (Result)
                {
                    Result = false;
                    foreach (char c in P)
                    {
                        foreach (char charLowerLetter in strLowerLetter)
                        {
                            if (charLowerLetter.Equals(c))
                            {
                                Result = true;
                                break;
                            }
                        }
                    }
                }
            }

            return Result;
        }

        /// <summary> 將文字加密回傳暗碼
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public string Encrypt(string data)
        {

            byte[] encrypted;
            // Create an Rijndael object
            // with the specified key and IV.
            using (Rijndael rijAlg = Rijndael.Create())
            {

                rijAlg.Key = Encoding.UTF8.GetBytes(key);
                rijAlg.IV = Encoding.UTF8.GetBytes(iv);

                // Create a decrytor to perform the stream transform.
                ICryptoTransform encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {

                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {

                            //Write all data to the stream.
                            swEncrypt.Write(data);
                            swEncrypt.Flush();
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }

            return Convert.ToBase64String(encrypted);
        }

        /// <summary> 將暗碼轉成明碼
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public string Decrypt(string data)
        {

            string plaintext = null;
            try
            {
                // Create an Rijndael object
                // with the specified key and IV.
                using (Rijndael rijAlg = Rijndael.Create())
                {
                    byte[] cipherText = Convert.FromBase64String(data);
                    rijAlg.Key = Encoding.UTF8.GetBytes(key);
                    rijAlg.IV = Encoding.UTF8.GetBytes(iv);

                    // Create a decrytor to perform the stream transform.
                    ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

                    // Create the streams used for decryption.
                    using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                    {
                        using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                            {

                                // Read the decrypted bytes from the decrypting stream
                                // and place them in a string.
                                plaintext = srDecrypt.ReadToEnd();
                            }
                        }
                    }

                }
            }
            catch
            {

            }
            return plaintext;
        }

        // 使用 RNGCryptoServiceProvider 產生由密碼編譯服務供應者 (CSP) 提供的亂數產生器。

        /// <summary>
        /// 產生一個非負數的亂數
        /// </summary>
        public int Next()
        {
            rngp.GetBytes(rb);
            int value = BitConverter.ToInt32(rb, 0);
            if (value < 0) value = -value;
            return value;
        }
        /// <summary>
        /// 產生一個非負數且最大值 max 以下的亂數
        /// </summary>
        /// <param name="max">最大值</param>
        public int Next(int max)
        {
            rngp.GetBytes(rb);
            int value = BitConverter.ToInt32(rb, 0);
            value %= (max + 1);
            if (value < 0) value = -value;
            return value;
        }
        /// <summary>
        /// 產生一個非負數且最小值在 min 以上最大值在 max 以下的亂數
        /// </summary>
        /// <param name="min">最小值</param>
        /// <param name="max">最大值</param>
        public int Next(int min, int max)
        {
            int value = Next(max - min) + min;
            return value;
        }
    }
}
