﻿using DDSC_Git.Helpers;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using Fortifydll;
using System.Text;
using System.Threading.Tasks;

namespace DDSC_Git
{
    class Program
    {
        private static readonly string Diff_Report_Folder_Name = "Diff_Report";
        private static readonly string Diff_Files_Folder_Name = "Diff_Files";
        static int Main(string[] args)
        {
            List<string> argsl = new List<string>();
            foreach (var item in args)
            {
                argsl.Add(cleanPathString(item));
            }
            args = argsl.ToArray();

            #region 00.描述
            if (args.Length == 0)
            {
                Console.WriteLine(" =====================================");
                Console.WriteLine("Copyright From DDSC");
                Console.WriteLine("This tool work on Windows and need to install node.JS.");
                Console.WriteLine("=====================================");
                Console.WriteLine("DDSC_Git.exe [${funtion}] ");
                Console.WriteLine("funtion: GetRTMVersion ");
                Console.WriteLine("funtion: Diff ");
                Console.WriteLine("funtion: TagPush ");
                Console.WriteLine("=====================================");
                Console.WriteLine("Configuration:");
                Console.WriteLine("Enter DDSC_Git.exe [${funtion}] to see Detail.");
                Console.WriteLine("=====================================");
                return 0;
            }

            if (args.Length < 1)
            {
                Console.Error.WriteLine("[Error]:: need args[0] funtion !!");
                return 1;
            }

            switch (args[0].ToLower())
            {
                case "getrtmversion":
                    return GetRTMVersion(args);
                case "getscanversion":
                    return GetScanVersion(args);
                case "diff":
                    return Diff(args);
                case "artifactpush":
                    return ArtifactPush(args);
                case "tagpush":
                    return TagPush(args);
                default:
                    break;
            }
            #endregion

            return 0;
        }

        private static int GetRTMVersion(string[] args)
        {
            #region 00.描述
            if (args.Length < 2)
            {
                Console.WriteLine("=====================================");
                Console.WriteLine("Configuration:");
                Console.WriteLine("DDSC_Git.exe GetRTMVersion [${WORKSPACE}] ");
                Console.WriteLine("WORKSPACE: Git workspace,this parameter is required.");
                Console.WriteLine("=====================================");
                return 0;
            }
            #endregion

            #region 01.參數初始化
            string gitPath;

            if (args.Length < 2)
            {
                Console.Error.WriteLine("[Error]:: need args[1] GitPath !!");
                return 1;
            }
            gitPath = args[1];

            #endregion

            #region 02.取得RTM版本
            GitHelper Object = new GitHelper(gitPath);
            var Result = Object.GetTagVersion(true, GitHelper.ResultTag.Tag_Type_RTM);

            if (Result.Status != GitHelper.Status.Success)
            {
                Console.Error.WriteLine("[Error]:: " + Result.Message);
                return 1;
            }
            string TagName;
            string Change_Type;
            if (Result.HeadTag == null)
            {
                TagName = Result.NextTag.TagName;
                Change_Type = "Add";
            }
            else
            {
                TagName = Result.HeadTag.TagName;
                Change_Type = "Update";
            }
            Console.WriteLine(string.Format("[Info]:: [RTMVersion]:: {0},{1}", TagName, Change_Type));
            #endregion

            return 0;
        }

        private static int GetScanVersion(string[] args)
        {
            #region 00.描述
            if (args.Length < 2)
            {
                Console.WriteLine("=====================================");
                Console.WriteLine("Configuration:");
                Console.WriteLine("DDSC_Git.exe GetScanVersion [${WORKSPACE}] ");
                Console.WriteLine("WORKSPACE: Git workspace,this parameter is required.");
                Console.WriteLine("=====================================");
                return 0;
            }
            #endregion

            #region 01.參數初始化
            string gitPath;

            if (args.Length < 2)
            {
                Console.Error.WriteLine("[Error]:: need args[1] GitPath !!");
                return 1;
            }
            gitPath = args[1];

            #endregion

            #region 02.取得Scan版本
            GitHelper Object = new GitHelper(gitPath);
            var Result = Object.GetTagVersion(true, GitHelper.ResultTag.Tag_Type_SCAN);

            if (Result.Status != GitHelper.Status.Success)
            {
                Console.Error.WriteLine("[Error]:: " + Result.Message);
                return 1;
            }
            string TagName;
            string Change_Type;
            if (Result.HeadTag == null)
            {
                TagName = Result.NextTag.TagName;
                Change_Type = "Add";
            }
            else
            {
                TagName = Result.HeadTag.TagName;
                Change_Type = "Update";
            }
            Console.WriteLine(string.Format("[Info]:: [ScanVersion]:: {0},{1}", TagName, Change_Type));
            #endregion

            return 0;
        }
        private static int Diff(string[] args)
        {
            #region 00.描述
            if (args.Length < 2)
            {
                Console.WriteLine("=====================================");
                Console.WriteLine("Configuration:");
                Console.WriteLine("DDSC_Git.exe diff [${WORKSPACE}] ${SourceVersion} ${CompareVersion} ${Type} ${Include} ${Exclude}  ${Report_Style} ${NoRenames} ${IgnoreSpace}");
                Console.WriteLine("WORKSPACE: Git workspace,this parameter is required.");
                Console.WriteLine("SourceVersion: Git workspace. Can use branch, tag, commitSHA or HEAD~n. Difault is 'HEAD'.");
                Console.WriteLine("CompareVersion: Git workspace. Can use branch, tag, commitSHA or HEAD~n. Difault is 'HEAD~1'.");
                Console.WriteLine("Type: Get first char to judge type. Difault is '1'.");
                Console.WriteLine("Type: 1.Generate diff report, and diff files artifact.");
                Console.WriteLine("Type: 2.Generate diff report, and all files artifact.");
                Console.WriteLine("Type: 3.Only generate diff report.");
                Console.WriteLine("Include: Scan include files, directory or file extension.");
                Console.WriteLine("Include: Use [Path] to include files or directory.");
                Console.WriteLine("Include: Use [*.name] to include file extension.");
                Console.WriteLine("Include: Use [;] to split patterns.");
                Console.WriteLine("Exclude: Scan exclude files, directory or file extension.");
                Console.WriteLine("Exclude: Use [Path] to exclude files or directory.");
                Console.WriteLine("Exclude: Use [*.name] to exclude file extension.");
                Console.WriteLine("Exclude: Use [;] to split patterns.");
                Console.WriteLine("Report_Style: side or line. Difault is 'side'.");
                Console.WriteLine("NoRenames: true or false. Difault is 'true'.");
                Console.WriteLine("IgnoreSpace: true or false. Difault is 'true'.");
                Console.WriteLine("=====================================");
                Console.WriteLine("Example:");
                Console.WriteLine(@"DDSC_Git.exe diff D:\DDSC_Git rc_master master 1 *.aspx;SRC/WEB SRC/packages");
                Console.WriteLine("=====================================");
                Console.WriteLine("Directory structure:");
                Console.WriteLine("${WORKSPACE}                                            #git workspace.");
                Console.WriteLine("+-    Diff_Artifact                                     #config Artifact_Folder_Name.");
                Console.WriteLine("|           +- Diff_Report                             ");
                Console.WriteLine("|                   +- Diff_File_FileName.txt           #config Diff_File_FileName.");
                Console.WriteLine("|                   +- Diff_Content_FileName.txt        #config Diff_Content_FileName.");
                Console.WriteLine("|                   +- Diff_Content_FileName.html       #config Diff_Content_html_FileName.");
                Console.WriteLine("|           +- Diff_Files                               ");
                Console.WriteLine("|                   +- Diff Source                      #git diff files with commit type 'Add' and 'Modify'.");
                Console.WriteLine("=====================================");
                return 0;
            }
            #endregion
            

            #region 01.參數初始化
            string Artifact_Folder_Name = cleanPathString(ConfigurationManager.AppSettings["Artifact_Folder_Name"]);
            string gitPath;
            string SourceVersion;
            string CompareVersion;
            DiffArtifactType Type;
            string[] Include;
            string[] IncludePath;
            string[] IncludeExtension;
            string[] Exclude;
            string[] ExcludePath;
            string[] ExcludeExtension;
            string diff2html_Parm_style;
            bool norenames = true;
            bool ignorespace=true;

            if (args.Length < 2)
            {
                Console.Error.WriteLine("[Error]:: need args[1] GitPath !!");
                return 1;
            }
            gitPath = args[1];

            if (args.Length < 3)
            {
                Console.WriteLine("[Warning]:: Args[2] CompareVersion is null, set dafault value 'HEAD' !!");
                SourceVersion = "HEAD";
            }
            else
            {
                SourceVersion = args[2];
            }

            if (args.Length < 4)
            {
                Console.WriteLine("[Warning]:: Args[3] CompareVersion is null, set dafault value 'HEAD~1' !!");
                CompareVersion = "HEAD~1";
            }
            else
            {
                CompareVersion = args[3];
            }


            if (args.Length < 5)
            {
                Console.WriteLine("[Warning]:: Args[4] Type is null, set dafault value '1' !!");
                Type = DiffArtifactType.DiffFilesArtifact;
            }
            else
            {
                string s = args[4].Substring(0, 1);

                if (s != "1" &&
                   s != "2" &&
                   s != "3")
                {
                    Console.Error.WriteLine("[Error]:: Type is not in (1,2,3)  !!");
                    return 1;
                }
                Type = (DiffArtifactType)int.Parse(s);
            }

            if (args.Length < 6)
            {
                Console.WriteLine("[Warning]:: Args[5] Include files is not setting !!");
                Include = new string[] { };
                IncludePath = new string[] { };
                IncludeExtension = new string[] { };
            }
            else
            {
                Include = args[5].Replace("/", @"\").Split(';');
                Console.WriteLine("[Info]:: Include:" + args[5]);
                IncludePath = Include.Where(x => !string.IsNullOrEmpty(x) && x.Substring(0, 1) != "*").Select(x => Path.Combine(gitPath, x))
                    .ToArray();
                IncludeExtension = Include.Where(x => !string.IsNullOrEmpty(x) && x.Substring(0, 1) == "*").Select(x => x.Split('*')[1])
                    .ToArray();
            }

            if (args.Length < 7)
            {
                Console.WriteLine("[Warning]:: Args[6] Exclude files is not setting !!");
                Exclude = new string[] { };
                ExcludePath = new string[] { };
                ExcludeExtension = new string[] { };
            }
            else
            {
                Exclude = args[6].Replace("/", @"\").Split(';');
                Console.WriteLine("[Info]:: Exclude:" + args[6]);
                ExcludePath = Exclude.Where(x => !string.IsNullOrEmpty(x) && x.Substring(0, 1) != "*").Select(x => Path.Combine(gitPath, x))
                    .ToArray();
                ExcludeExtension = Exclude.Where(x => !string.IsNullOrEmpty(x) && x.Substring(0, 1) == "*").Select(x => x.Split('*')[1])
                    .ToArray();
            }
            if (args.Length < 8)
            {
                diff2html_Parm_style = ConfigurationManager.AppSettings["diff2html_Parm_style"];
                Console.WriteLine(string.Format("[Warning]:: Args[7] report style is null, set dafault value {0} !!", diff2html_Parm_style));
            }
            else
            {
                diff2html_Parm_style = args[7];
            }

            if (args.Length < 9)
            {
                ignorespace = true;
                Console.WriteLine("[Warning]:: Args[8] norenames is null, set dafault value true !!");
            }
            else
            {
                if (args[8].ToLower() == "true")
                {
                    norenames = true;

                }
                else if (args[8].ToLower() == "false")
                {
                    norenames = false;
                }
                else
                {
                    Console.Error.WriteLine("[Error]:: norenames is not in (true,false)  !!");
                    return 1;
                }
            }
            if (args.Length < 10)
            {
                ignorespace = true;
                Console.WriteLine("[Warning]:: Args[9] ignorespace is null, set dafault value true !!");
            }
            else
            {
                if(args[9].ToLower() == "true")
                {
                    ignorespace = true;

                }
                else if (args[9].ToLower() == "false")
                {
                    ignorespace = false;
                }
                else
                {
                    Console.Error.WriteLine("[Error]:: ignorespace is not in (true,false)  !!");
                    return 1;
                }
            }
            #endregion

            #region 02.取得差異資訊
            Console.WriteLine("Get diff information start...");
            GitHelper DiffObject = new GitHelper(gitPath);
            var DiffResult = DiffObject.GetDiff(SourceVersion, CompareVersion, norenames: norenames, ignorespace:ignorespace);

            if (DiffResult.Status != GitHelper.Status.Success)
            {
                Console.Error.WriteLine("[Error]:: " + DiffResult.Message);
                return 1;
            }
            Console.WriteLine("Get diff information success.");
            #endregion

            #region 03.建立成品目錄
            Console.WriteLine("Create diff Artifact folder...");
            string Diff_Artifact = Path.Combine(gitPath, Artifact_Folder_Name);
            if (Directory.Exists(Diff_Artifact))
            {
                Directory.Delete(Diff_Artifact, true);
            }
            Directory.CreateDirectory(Diff_Artifact);
            string Diff_Report = Path.Combine(Diff_Artifact, Diff_Report_Folder_Name);
            string Diff_Files = Path.Combine(Diff_Artifact, Diff_Files_Folder_Name);
            Directory.CreateDirectory(Diff_Report);
            if(Type != DiffArtifactType.NOArtifact)
            {
                Directory.CreateDirectory(Diff_Files);
            }
            Console.WriteLine("Create diff Artifact folder success.");
            #endregion

            #region 04.建立差異檔案
            Console.WriteLine("Generate diff txt files...");
            string ChangedContentPath = Path.Combine(Diff_Report, cleanPathString(ConfigurationManager.AppSettings["Diff_File_FileName"]));
            File.WriteAllText(ChangedContentPath, DiffResult.ChangedContent);

            string ComparedContentPath = Path.Combine(Diff_Report, cleanPathString(ConfigurationManager.AppSettings["Diff_Content_FileName"]));
            File.WriteAllText(ComparedContentPath, DiffResult.ComparedContent);

            string ComparedContentOriginPath = Path.Combine(Diff_Report, "diff_origin.txt");
            File.WriteAllText(ComparedContentOriginPath, DiffResult.ComparedContentOrigin);
            Console.WriteLine("Generate diff txt success.");
            #endregion

            #region 05.建立差異html
            Console.WriteLine("Generate diff html start...");
            string Diff2htmlExe = Path.Combine(new string[] { AppDomain.CurrentDomain.BaseDirectory, "diff2html", "diff2html.cmd" });
            string Diff2htmlTemplate = Path.Combine(new string[] { AppDomain.CurrentDomain.BaseDirectory, "template", cleanPathString(ConfigurationManager.AppSettings["diff2html_Parm_hwt"]) });

            string Diff2htmlarg = String.Format("--style {0} --summary {1} -F \"{2}\" --hwt \"{3}\" -i file -- \"{4}\"",
                diff2html_Parm_style,
                cleanPathString(ConfigurationManager.AppSettings["diff2html_Parm_summary"]),
                Path.Combine(Diff_Report, cleanPathString(ConfigurationManager.AppSettings["Diff_Content_html_FileName"])),
                Diff2htmlTemplate,
                ComparedContentOriginPath);
            ProcessStartInfo psInfo = new ProcessStartInfo(Diff2htmlExe, Diff2htmlarg)
            {
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
                UseShellExecute = false
            };

            string stdoutput;
            string stderror;
            using (Process ps = Process.Start(psInfo))
            {

                stdoutput = ps.StandardOutput.ReadToEnd();
                stderror = ps.StandardError.ReadToEnd();
                ps.WaitForExit(60000);
                if (!ps.HasExited)
                {
                    ps.Kill();
                }
                ps.Close();
            }
            if (!string.IsNullOrEmpty(stderror))
            {
                Console.Error.WriteLine("[Warning]:: Generate diff failed !");
                Console.Error.WriteLine("[Warning]:: " + stderror);
                //return 1;
            }

            File.Delete(ComparedContentOriginPath);
            Console.WriteLine("Generate diff html success.");
            #endregion

            #region 06.複製成品檔案
            if(Type != DiffArtifactType.NOArtifact)
            {
                string Artifact_MoveOrCopy = cleanPathString(ConfigurationManager.AppSettings["Artifact_MoveOrCopy"]).ToLower();
                Console.WriteLine(Artifact_MoveOrCopy + " add or modify files to Artifact folder start...");
                if(Type == DiffArtifactType.DiffFilesArtifact)
                {
                    foreach (var item in DiffResult.AorMFilesPath)
                    {
                        
                        string filePath = Path.Combine(gitPath, item).Replace("/", @"\");
                        string ArtifactfilePath = filePath.Replace(gitPath, Diff_Files).Replace("/", @"\");
                        string fileFolder = Path.GetDirectoryName(filePath).Replace("/", @"\");
                        string ArtifactfileFolder = fileFolder.Replace(gitPath, Diff_Files).Replace("/", @"\");
                        if (IncludePath.Count() != 0 && !IncludePath.Any(filePath.Contains))
                        {
                            continue;
                        }

                        if (IncludeExtension.Count() != 0 && !IncludeExtension.Any(Path.GetExtension(filePath).Equals))
                        {
                            continue;
                        }

                        if (ExcludePath.Count() != 0 && ExcludePath.Any(filePath.Contains))
                        {
                            continue;
                        }

                        if (ExcludeExtension.Count() != 0 && ExcludeExtension.Any(Path.GetExtension(filePath).Equals))
                        {
                            continue;
                        }

                        if (!Directory.Exists(@"\\?\" + ArtifactfileFolder))
                        {
                            Directory.CreateDirectory(@"\\?\" + ArtifactfileFolder);
                        }
                        if (Artifact_MoveOrCopy == "copy")
                        {
                            File.Copy(@"\\?\" + filePath, @"\\?\" + ArtifactfilePath);
                        }
                        else
                        {
                            File.Move(@"\\?\" + filePath, @"\\?\" + ArtifactfilePath);
                        }
                    }
                }
                else if (Type == DiffArtifactType.AllFilesArtifact)
                {
                    var FilesList = Directory.GetFiles(gitPath, "*", SearchOption.AllDirectories)
                    .Where(x => !x.Contains(Path.Combine(gitPath, ".git"))
                    && !x.Contains(Path.Combine(gitPath, Artifact_Folder_Name))
                    );

                    if (IncludePath.Count() != 0)
                    {
                        FilesList = FilesList.Where(x => IncludePath.Any(x.Contains));
                    }
                    if (IncludeExtension.Count() != 0)
                    {
                        FilesList = FilesList.Where(x => IncludeExtension.Any(Path.GetExtension(x).Equals));
                    }
                    if (ExcludePath.Count() != 0)
                    {
                        FilesList = FilesList.Where(x => !ExcludePath.Any(x.Contains));
                    }
                    if (ExcludeExtension.Count() != 0)
                    {
                        FilesList = FilesList.Where(x => !ExcludeExtension.Any(Path.GetExtension(x).Equals));
                    }

                    if (Artifact_MoveOrCopy == "copy")
                    {
                        foreach (var item in FilesList)
                        {
                            string dest = item.Replace(gitPath, Diff_Files);
                            string destdir = Path.GetDirectoryName(dest);
                            if (!Directory.Exists(@"\\?\" + destdir))
                            {
                                Directory.CreateDirectory(@"\\?\" + destdir);
                            }
                            File.Copy(@"\\?\" + item, @"\\?\" + dest);
                        }

                    }
                    else
                    {
                        foreach (var item in FilesList)
                        {
                            string dest = item.Replace(gitPath, Diff_Files);
                            string destdir = Path.GetDirectoryName(dest);
                            if (!Directory.Exists(@"\\?\" + destdir))
                            {
                                Directory.CreateDirectory(@"\\?\" + destdir);
                            }
                            File.Move(@"\\?\" + item, @"\\?\" + dest);
                        }

                    }
                }
                
                Console.WriteLine(Artifact_MoveOrCopy + " add or modify files to Artifact folder success.");
            }
            
            #endregion

            Console.WriteLine("Steps all successful !!");

            return 0;
        }

        private static int TagPush(string[] args)
        {
            #region 00.描述
            if (args.Length < 2)
            {
                Console.WriteLine("=====================================");
                Console.WriteLine("Configuration:");
                Console.WriteLine("DDSC_Git.exe TagPush [${WORKSPACE}] [${TagName}] ${Type} ${Message} ");
                Console.WriteLine("WORKSPACE: Git workspace,this parameter is required.");
                Console.WriteLine("TagName: Git TagName,this parameter is required.");
                Console.WriteLine("Type: Tag run type. Difault is 'Add'.");
                Console.WriteLine("Type: Add");
                Console.WriteLine("Type: Update");
                Console.WriteLine("Type: Remove");
                Console.WriteLine("Message: Git tag message. Difault is ''.");
                Console.WriteLine("Message: Enter this parameter to be annotated tag, or lightweight tag.");
                Console.WriteLine("=====================================");
                return 0;
            }
            #endregion

            #region 01.參數初始化
            string gitPath;
            string TagName;
            string Type = "";
            string Message = "";

            if (args.Length < 2)
            {
                Console.Error.WriteLine("[Error]:: need args[1] GitPath !!");
                return 1;
            }
            gitPath = args[1];

            if (args.Length < 3)
            {
                Console.Error.WriteLine("[Error]:: need args[2] TagName !!");
                return 1;
            }
            TagName = args[2];


            if (args.Length < 4)
            {
                Console.WriteLine("[Warning]:: Args[3] Type is null, set dafault value 'Add' !!");
                Type = "Add";
            }
            else
            {
                string s = args[3].ToLower();

                if (s != "add" &&
                   s != "update" &&
                   s != "remove")
                {
                    Console.Error.WriteLine("[Error]:: Type is not in (Add,Update,Remove)  !!");
                    return 1;
                }
                Type = s;
            }

            if (args.Length < 5)
            {
                Console.WriteLine("[Warning]:: Args[4] Message is null, set dafault value '', tag is lightweight tag !!");
            }
            else
            {
                Message = args[4];
            }

            #endregion

            #region 02.遠端打Tag
            Console.WriteLine("Add tag start...");
            GitHelper Object = new GitHelper(gitPath);
            var Result = Object.TagPush(TagName, Type, Message);

            if (Result.Status != GitHelper.Status.Success)
            {
                Console.Error.WriteLine("[Error]:: " + Result.Message);
                return 1;
            }
            Console.WriteLine("Add tag success.");
            #endregion

            return 0;
        }

        private static int ArtifactPush(string[] args)
        {
            #region 00.描述
            if (args.Length < 2)
            {
                Console.WriteLine("=====================================");
                Console.WriteLine("Configuration:");
                Console.WriteLine("DDSC_Git.exe ArtifactPush [${ArtifactFolderPath}] [${ArtifactName}] [${ZipFolderPath}] [${UploadPath}] ");
                Console.WriteLine("=====================================");
                Console.WriteLine("ArtifactFolderPath Not equal ZipFolderPath");
                Console.WriteLine("=====================================");
                return 0;
            }
            #endregion


            #region 01.參數初始化
            string ArtifactFolderPath;
            string ArtifactName;
            string ZipFolderPath;
            string UploadPath;
            

            if (args.Length < 2)
            {
                Console.Error.WriteLine("[Error]:: need args[1] ArtifactFolderPath !!");
                return 1;
            }
            ArtifactFolderPath = args[1];

            if (args.Length < 3)
            {
                Console.Error.WriteLine("[Error]:: need args[2] ArtifactName !!");
                return 1;
            }
            ArtifactName = args[2];

            if (args.Length < 4)
            {
                Console.Error.WriteLine("[Error]:: need args[3] ZipFolderPath !!");
                return 1;
            }
            ZipFolderPath = args[3];

            if (args.Length < 5)
            {
                Console.Error.WriteLine("[Error]:: need args[4] UploadPath !!");
                return 1;
            }
            UploadPath = args[4];
            #endregion

            #region 02.檢查參數
            if (!Directory.Exists(ArtifactFolderPath))
            {
                Console.Error.WriteLine("[Error]:: ArtifactFolderPath Not exist !!");
                return 1;
            }

            if (!Directory.Exists(ZipFolderPath))
            {
                Console.Error.WriteLine("[Error]:: ZipFolderPath Not exist !!");
                return 1;
            }

            if(new DirectoryInfo(ArtifactFolderPath).FullName == new DirectoryInfo(ZipFolderPath).FullName)
            {
                Console.Error.WriteLine("[Error]:: ArtifactFolderPath Not equal ZipFolderPath !!");
                return 1;
            }
            #endregion

            #region 03.壓縮目標目錄
            Console.WriteLine("Create zip file start...");
            ZipFile.CreateFromDirectory(ZipFolderPath, Path.Combine(ArtifactFolderPath, ArtifactName));
            Console.WriteLine("Create zip file success.");
            #endregion

            #region 04.上傳成品
            Console.WriteLine("Upload zip file to ftps start...");
            PHelper P = new PHelper();

            bool FtpsSuccess = false;

            try
            {
                Console.WriteLine("Upload zip file to ftps1 start...");
                FtpsHelper ftpsHelper = new FtpsHelper(cleanPathString(ConfigurationManager.AppSettings["Ftps_host"]),
                    int.Parse(cleanPathString(ConfigurationManager.AppSettings["Ftps_port"])),
                    P.Decrypt(cleanPathString(ConfigurationManager.AppSettings["Ftps_U"])),
                    P.Decrypt(cleanPathString(ConfigurationManager.AppSettings["Ftps_P"])));
                ftpsHelper.Connect();
                ftpsHelper.Put(Path.Combine(ArtifactFolderPath, ArtifactName), UploadPath);
                ftpsHelper.Disconnect();
                FtpsSuccess = true;
                Console.WriteLine("Upload zip file to ftps1 Success.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.WriteLine("[Warning]:: Upload zip file to ftps1 Failed.");
            }

            System.Threading.Thread.Sleep(5000);

            try
            {
                Console.WriteLine("Upload zip file to ftps2 start...");
                FtpsHelper ftpsHelper2 = new FtpsHelper(cleanPathString(ConfigurationManager.AppSettings["Ftps_host2"]),
                    int.Parse(cleanPathString(ConfigurationManager.AppSettings["Ftps_port2"])),
                    P.Decrypt(cleanPathString(ConfigurationManager.AppSettings["Ftps_U2"])),
                    P.Decrypt(cleanPathString(ConfigurationManager.AppSettings["Ftps_P2"])));
                ftpsHelper2.Connect();
                ftpsHelper2.Put(Path.Combine(ArtifactFolderPath, ArtifactName), UploadPath);
                ftpsHelper2.Disconnect();
                FtpsSuccess = true;
                Console.WriteLine("Upload zip file to ftps2 Success.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                Console.WriteLine("[Warning]:: Upload zip file to ftps2 Failed.");
            }

            if (!FtpsSuccess)
            {
                Console.Error.WriteLine("[Error]:: Upload zip file to ftps All Failed.");
                return 1;
            }
            Console.WriteLine("Upload zip file to ftps success.");
            #endregion

            Console.WriteLine("Steps all successful !!");

            return 0;
        }
        enum DiffArtifactType
        {
            DiffFilesArtifact = 1,
            AllFilesArtifact = 2,
            NOArtifact = 3
        }

        enum TagType
        {
            Add = 1,
            Update = 2,
            Remove = 3
        }

        private static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            // Get the subdirectories for the specified directory.
            DirectoryInfo dir = new DirectoryInfo(sourceDirName);

            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException(
                    "Source directory does not exist or could not be found: "
                    + sourceDirName);
            }

            DirectoryInfo[] dirs = dir.GetDirectories();

            // If the destination directory doesn't exist, create it.       
            Directory.CreateDirectory(destDirName);

            // Get the files in the directory and copy them to the new location.
            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo file in files)
            {
                string tempPath = Path.Combine(destDirName, file.Name);
                file.CopyTo(tempPath, false);
            }

            // If copying subdirectories, copy them and their contents to new location.
            if (copySubDirs)
            {
                foreach (DirectoryInfo subdir in dirs)
                {
                    string tempPath = Path.Combine(destDirName, subdir.Name);
                    DirectoryCopy(subdir.FullName, tempPath, copySubDirs);
                }
            }
        }

        public static String cleanPathString(String aString)
        {
            PathManipulation pathManipulation = new PathManipulation();
            return pathManipulation.cleanPathString(aString);
        }

    }

}
